# TV Launcher (Google TV)

Hızlı, sade ve modern bir Google TV / Android TV launcher'ı. Kotlin + Compose for TV ile yazıldı.

## Özellikler
- Büyük saat, tarih ve günün saatine göre karşılama
- Banner'lı 16:9 uygulama kartları, odaklanınca büyüme + beyaz çerçeve
- Uygulama yüklenince/silinince liste otomatik güncellenir
- Uzun basış (OK tuşunu basılı tut) → uygulama bilgisi / kaldırma
- Önce TV uygulamaları, sonra diğerleri, alfabetik

## APK nasıl alınır

### Yol 1: GitHub (bilgisayarda kurulum gerektirmez)
1. github.com'da ücretsiz hesapla yeni bir repo aç.
2. Bu klasörün içeriğini repoya yükle (`.github` klasörü dahil).
3. Repo'da **Actions** sekmesi → **APK derle** → bitince **TVLauncher-apk** artifact'ını indir.
4. Zip'in içindeki `app-debug.apk` dosyası hazır.

### Yol 2: Android Studio
1. Klasörü Android Studio ile aç, Gradle sync bitsin.
2. **Build → Build APK(s)**. Dosya `app/build/outputs/apk/debug/` altında çıkar.

## TV'ye kurma
- Telefondan/bilgisayardan **Send Files to TV** ya da **Downloader** uygulamasıyla APK'yı TV'ye aktar, aç ve kur.
- Veya ADB ile: `adb connect TV_IP:5555` → `adb install app-debug.apk`
- Kurduktan sonra Home tuşuna basınca "Bu launcher'ı kullan" seçeneği çıkmazsa:
  Ayarlar → Uygulamalar → Varsayılan uygulamalar → Ana ekran bölümünden seç.
  (Bazı Google TV sürümleri yalnızca sistem launcher'ına izin verir; o durumda uygulama menüden normal şekilde açılır.)
